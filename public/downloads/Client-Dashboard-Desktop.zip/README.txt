CLIENT DASHBOARD — PERSONAL DESKTOP ACCESS

Extract the ZIP and move the Windows .url or Mac .webloc file to your desktop.
Internet access and your personal dashboard username/password are required.
These open the same online workspace; they are not offline executables.
Website: https://your-dashboard.example.com
